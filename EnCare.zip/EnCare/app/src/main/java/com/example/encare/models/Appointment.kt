package com.example.encare.models

class Appointment {

}