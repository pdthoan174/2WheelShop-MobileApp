package com.example.encare

object Api {

}
